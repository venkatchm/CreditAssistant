from __future__ import annotations

from fastapi import APIRouter

from app.repositories.json_credit_repository import JsonCreditRepository
from app.services.credit_service import CreditService
from synthetic.models import CreditMetrics, CreditProfile, Recommendation


router = APIRouter(prefix="/credit", tags=["credit"])


def get_credit_service() -> CreditService:
    return CreditService(JsonCreditRepository())


@router.get("/profile/{user_id}", response_model=CreditProfile)
def get_credit_profile(user_id: str) -> CreditProfile:
    return get_credit_service().get_credit_profile(user_id)


@router.get("/recommendations/{user_id}", response_model=list[Recommendation])
def get_credit_recommendations(user_id: str) -> list[Recommendation]:
    return get_credit_service().get_recommendations(user_id)


@router.get("/metrics/{user_id}", response_model=CreditMetrics)
def get_credit_metrics(user_id: str) -> CreditMetrics:
    return get_credit_service().get_credit_metrics(user_id)
