from pydantic import BaseModel
from typing import List

class QuestionRequest(BaseModel):
    name: str
    skills: List[str]
    experience: int
