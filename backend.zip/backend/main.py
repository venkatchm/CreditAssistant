from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes.credit import router as credit_router
from question_generator import generate_questions
from resume_parser import parse_resume
from schemas import QuestionRequest
from synthetic.seed_data import seed_data

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

seed_data()
app.include_router(credit_router)

@app.post("/parse-resume")
async def parse_resume_endpoint(file: UploadFile = File(...)):
    return await parse_resume(file)

@app.post("/generate-questions")
async def generate_questions_endpoint(payload: QuestionRequest):
    return generate_questions(payload)
