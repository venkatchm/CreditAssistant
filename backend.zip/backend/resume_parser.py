async def parse_resume(file):
    return {
        "name": "Jane Doe",
        "skills": ["Python", "React", "FastAPI"],
        "experience": 5
    }
