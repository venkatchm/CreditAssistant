def generate_questions(payload):
    return {
        "questions": [
            f"Can you describe your experience with {payload.skills[0]}?",
            "Tell us about a project that challenged you technically.",
            "How do you stay current with new technologies?"
        ]
    }
